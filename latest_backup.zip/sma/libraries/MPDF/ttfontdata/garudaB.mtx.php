<?php
$name='Garuda-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 1284,
  'Descent' => -591,
  'CapHeight' => 1284,
  'Flags' => 262148,
  'FontBBox' => '[-750 -591 1099 1337]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 766,
);
$up=-37;
$ut=20;
$ttffile='D:/wamp/www/sma3/sma/libraries/MPDF/ttfonts/Garuda-Bold.ttf';
$TTCfontID='0';
$originalsize=57796;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='garudaB';
$panose=' 0 0 2 b 7 4 2 2 2 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>