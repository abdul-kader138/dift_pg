<?php
$name='Garuda';
$type='TTF';
$desc=array (
  'Ascent' => 1284,
  'Descent' => -591,
  'CapHeight' => 1284,
  'Flags' => 4,
  'FontBBox' => '[-659 -589 1090 1288]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 766,
);
$up=-32;
$ut=10;
$ttffile='D:/wamp/www/sma3/sma/libraries/MPDF/ttfonts/Garuda.ttf';
$TTCfontID='0';
$originalsize=57324;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='garuda';
$panose=' 0 0 2 b 6 4 2 2 2 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>