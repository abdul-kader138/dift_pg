
<style>
.table th { text-align:center; }
.table td { text-align:center; }
.table a:hover { text-decoration: none; }
.cl_wday { text-align: center; font-weight:bold; }
.cl_equal { width: 14%; }
.day { width: 14%; }
.day_num { width: 100%; text-align:center; margin: -8px; padding:8px; } 
.content { width: 100%; /*color: #2FA4E7;*/ margin-top:5px; }
.data td:first-child { text-align: left; vertical-align:middle; }
.data td:last-child { text-align: right; vertical-align:middle; }
.highlight { color: #0088CC; font-weight:bold; }
</style>
<h3 class="title"><?php echo $page_title; ?></h3>

<p>&nbsp;</p>
	<div>
    <?php echo $calender; ?>
    </div>
