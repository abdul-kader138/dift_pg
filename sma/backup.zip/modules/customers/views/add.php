<script src="<?php echo $this->config->base_url(); ?>assets/js/validation.js"></script>
<script type="text/javascript">
$(function() {
	$('form').form();
});
</script>

<?php if($message) { echo "<div class=\"alert alert-error\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>


	<h3 class="title"><?php echo $page_title; ?></h3>
	<p><?php echo $this->lang->line("enter_info"); ?></p>

   	<?php $attrib = array('class' => 'form-horizontal'); echo form_open("module=customers&view=add", $attrib);?>

<div class="control-group">
  <label class="control-label" for="cf3" required="required" data-error="Customer Group is required">Customer Group</label>
  <div class="controls">
    <select name="cf3" id="cf3">
      <option value="">Select customer Group</option>
      <option value="Corporate">Corporate</option>
      <option value="Regular">Regular</option>
      
    </select>
  </div>
</div> 

<div class="control-group">
  <label class="control-label" for="name"><?php echo $this->lang->line("name"); ?></label>
  <div class="controls"> <?php echo form_input($name, '', 'class="span4" id="name" pattern=".{2,55}" required="required" data-error="'.$this->lang->line("name").' '.$this->lang->line("is_required").'"');?>
  </div>
</div> 

<div class="control-group">
  <label class="control-label" for="email_address"><?php echo $this->lang->line("email_address"); ?></label>
  <div class="controls"> <input type="email" name="email" class="span4" required="required" data-error="<?php echo $this->lang->line("email_address").' '.$this->lang->line("is_required"); ?>" />
  </div>
</div> 

<div class="control-group">
  <label class="control-label" for="cf4">Card No</label>
  <div class="controls"> <input type="text" name="cf4" class="span4" required="required" data-error="<?php echo 'Card No is required'.' '.$this->lang->line("is_required"); ?>" />
  </div>
</div> 

<div class="control-group">
  <label class="control-label" for="phone"><?php echo $this->lang->line("phone"); ?></label>
  <div class="controls"> <input type="tel" name="phone" class="span4" pattern="[0-9]{7,15}" required="required" data-error="<?php echo $this->lang->line("phone").' '.$this->lang->line("is_required"); ?>" />
  </div>
</div> 
<div class="control-group">
  <label class="control-label" for="company"><?php echo $this->lang->line("company"); ?></label>
  <div class="controls"> <?php echo form_input($company, '', 'class="span4 tip" title="'.$this->lang->line("bypass").'" id="company" pattern=".{1,55}" required="required" data-error="'.$this->lang->line("company").' '.$this->lang->line("is_required").'"');?>
  </div>
</div> 
<div class="control-group">
  <label class="control-label" for="address"><?php echo $this->lang->line("address"); ?></label>
  <div class="controls"> <?php echo form_input($address, '', 'class="span4" id="address" pattern=".{2,255}" required="required" data-error="'.$this->lang->line("address").' '.$this->lang->line("is_required").'"');?>
  </div>
</div>  

<div class="control-group" style="display:none">
  <label class="control-label" for="city"><?php echo $this->lang->line("city"); ?></label>
  <div class="controls"> <?php echo form_input($city, '', 'class="span4" id="city" pattern=".{2,55}" data-error="'.$this->lang->line("city").' '.$this->lang->line("is_required").'"');?>
  </div>
</div> 
<div class="control-group" style="display:none">
  <label class="control-label" for="state"><?php echo $this->lang->line("state"); ?></label>
  <div class="controls"> <?php echo form_input($state, '', 'class="span4" id="state" pattern=".{2,55}" data-error="'.$this->lang->line("state").' '.$this->lang->line("is_required").'"');?>
  </div>
</div> 
<div class="control-group" style="display:none">
  <label class="control-label" for="postal_code"><?php echo $this->lang->line("postal_code"); ?></label>
  <div class="controls"> <?php echo form_input($postal_code, '', 'class="span4" id="postal_code"pattern=".{4,8}" data-error="'.$this->lang->line("postal_code").' '.$this->lang->line("is_required").'"');?>
  </div>
</div> 
<div class="control-group" style="display:none">
  <label class="control-label" for="country"><?php echo $this->lang->line("country"); ?></label>
  <div class="controls"> <?php echo form_input($country, '', 'class="span4" id="country" pattern=".{2,55}" data-error="'.$this->lang->line("country").' '.$this->lang->line("is_required").'"');?>
  </div>
</div> 


<div class="control-group">
  <label class="control-label" for="cf1">Discount Set As</label>
  <div class="controls">
    <select name="cf1" id="cf1" required="required" data-error="Discount Set is required" >
      <option value="">Select Discount Set</option>
      <option value="Paragon Products">Paragon Products</option>
       <option value="All Products">All Products</option>
    </select>
  </div>
</div> 

<div class="control-group">
    <label class="control-label" for="cf5">Discount Amount</label>
    <div class="controls">
        <?php
        foreach ($discounts as $discount) {
            $ds[$discount->id] = $discount->name;
        }
        echo form_dropdown('cf5', $ds, (isset($_POST['cf5']) ? $_POST['cf5'] : ""), 'class="span11 tip chzn-select" data-placeholder="' . $this->lang->line("select") . ' ' . $this->lang->line("default_discount") . '" required="required" data-error="' . $this->lang->line("default_discount") . ' ' . $this->lang->line("is_required") . '"');
        ?>
    </div>
</div>

<!-- 

<div class="control-group">
  <label class="control-label" for="cf3"><?php echo $this->lang->line("ccf3"); ?></label>
  <div class="controls"> <?php echo form_input('cf3', '', 'class="span4" id="cf3"');?>
  </div>
</div> 
<div class="control-group">
  <label class="control-label" for="cf4"><?php echo $this->lang->line("ccf4"); ?></label>
  <div class="controls"> <?php echo form_input('cf4', '', 'class="span4" id="cf4"');?>
  </div>
</div> 
<div class="control-group">
  <label class="control-label" for="cf5"><?php echo $this->lang->line("ccf5"); ?></label>
  <div class="controls"> <?php echo form_input('cf5', '', 'class="span4" id="cf5"');?>
  </div>
</div> 
<div class="control-group">
  <label class="control-label" for="cf6"><?php echo $this->lang->line("ccf6"); ?></label>
  <div class="controls"> <?php echo form_input('cf6', '', 'class="span4" id="cf6"');?>
  </div>
</div>  -->

<div class="control-group">
  <div class="controls"> <?php echo form_submit('submit', $this->lang->line("add_customer"), 'class="btn btn-primary"');?> </div>
</div>
<?php echo form_close();?> 
   